# mypackage
This library was creadted as an example to publish python package code to github 